package com.huhy.main;

public class Message {

	private boolean isOrder;
	private String clientID;
	
    private String orderID;
    
	
	
	
}
