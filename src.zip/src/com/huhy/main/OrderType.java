package com.huhy.main;

public enum OrderType {
			BUY,SELL
			
}
