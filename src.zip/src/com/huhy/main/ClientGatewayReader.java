package com.huhy.main;

public class ClientGatewayReader implements Runnable {

	
	// This class will implement runnable and will run ON THE CLIENT
	// it will connect to the server, and listen for all messages from the gateway 
	// destined for the particular client's ID
	
	// make socket connection
	// two pass string indicating client ID, type FEED.
	// listen in loop for messages.
	// print messages out.
	
	public void run(){
		
	}
	
	
}
