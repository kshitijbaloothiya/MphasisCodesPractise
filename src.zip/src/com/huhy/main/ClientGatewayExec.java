package com.huhy.main;

public class ClientGatewayExec implements Runnable {

	//This class will represent the LOCAL client exec feed.
	
	public void run(){
		
	}
	
}
