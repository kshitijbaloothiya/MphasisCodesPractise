package com.mphasis.springboot.entapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntappApplication {

	public static void main(String[] args) {
		SpringApplication.run(EntappApplication.class, args);
	}

}
