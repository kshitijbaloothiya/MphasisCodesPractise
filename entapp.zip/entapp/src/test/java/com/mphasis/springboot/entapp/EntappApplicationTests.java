package com.mphasis.springboot.entapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntappApplicationTests {

	@Test
	void contextLoads() {
	}

}
